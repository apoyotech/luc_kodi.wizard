'''#####-----Build File-----#####'''
buildfile = 'https://mia.nl.tab.digital/s/oqWJa25ZsG4XoXx/download/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
