'''#####-----Build File-----#####'''
buildfile = 'https://mia.nl.tab.digital/s/Cw8sENXo8wEBzqi/download/builds.xml'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
